###########CODE FOR TYPING GAME###########
def game(speed,text,score):
    throwawayvariable = str(raw_input("You will be given a message, type it back. \nNot only does it have to be perfect it has to be done in less than {} seconds!\nClick Enter to Begin  ".format(speed)))

    starttime=default_timer()

    theirAnswer=str(raw_input("type this text : {}\n".format(text)))
    stoptime = default_timer()
    totalTime = stoptime - starttime
    if totalTime<=speed and theirAnswer ==text:
        print ("Good!!")
        print ("You have done it in {} seconds !".format(totalTime))
        score[0]=score[0]+1
    else:
        print ("Total Bummer!!!!!!")
        print ("You have done it in {} seconds !".format(totalTime))
        score[1]=score[1]+1
        

    return score

########### END OF TYPING GAME CODE ############



##########CODE FOR TIC TAC TOE###############
def tic_tac_toe():
    import random
    while True:
        a=str(raw_input("what you want to be X or O"))
        if a=="x" or a=="X":
            player="X"
            computer="O"
            break
        if a=="o"or a=="O":
            player="O"
            computer="X"
            break
        else:
            continue
    b=[0,1,2,3,4,5,6,7,8,9]
    o=[1,2,3,4,5,6,7,8,9]
    d=["Computer's turn","Your Turn"]
    print b[1],"|",b[2],"|",b[3]
    print "_________"
    print b[4],"|",b[5],"|",b[6]
    print "_________"
    print b[7],"|",b[8],"|",b[9]
    
    e=random.randint(0,1)
    
    if e==1:
        print "It's Your turn"
        while True:
            c=int(raw_input("select your place (1,9)"))
            if c in o:
                break
            else:
                continue
        b[c]=player
        print b[1],"|",b[2],"|",b[3]
        print "_________"
        print b[4],"|",b[5],"|",b[6]
        print "_________"
        print b[7],"|",b[8],"|",b[9]
        
    if e==0:
        print "computer's turn"
        f=random.randint(1,9)
        b[f]=computer
        print b[1],"|",b[2],"|",b[3]
        print "_________"
        print b[4],"|",b[5],"|",b[6]
        print "_________"
        print b[7],"|",b[8],"|",b[9]

    while True:
        if e==1:
            print "computer's turn"
            while True:
                f=random.randint(1,9)
                if b[f]=="X" or b[f]=="O":
                    continue
                else:
                    b[f]=computer
                    break
            print b[1],"|",b[2],"|",b[3]
            print "_________"
            print b[4],"|",b[5],"|",b[6]
            print "_________"
            print b[7],"|",b[8],"|",b[9]
            if b[1]==b[2]==b[3] or b[4]==b[5]==b[6] or b[7]==b[8]==b[9] or b[1]==b[4]==b[7] or b[2]==b[5]==b[8] or b[3]==b[6]==b[9] or b[1]==b[5]==b[9] or b[3]==b[5]==b[7]:
                print"Computer Won"
                break
            print "It's Your turn"
            while True:
                while True:
                    c=int(raw_input("select your place (1,9)"))
                    if c in o:
                        break
                    else:
                        continue
                if b[c]=="X" or b[c]=="O":
                    continue
                else:
                    b[c]=player
                    break
            print b[1],"|",b[2],"|",b[3]
            print "_________"
            print b[4],"|",b[5],"|",b[6]
            print "_________"
            print b[7],"|",b[8],"|",b[9]
            if b[1]==b[2]==b[3] or b[4]==b[5]==b[6] or b[7]==b[8]==b[9] or b[1]==b[4]==b[7] or b[2]==b[5]==b[8] or b[3]==b[6]==b[9] or b[1]==b[5]==b[9] or b[3]==b[5]==b[7]:
                print"You Won"
                break
        if e==0:
            while True:
                print "It's Your turn"
                while True:
                    c=int(raw_input("select your place (1,9)"))
                    if c in o:
                        break
                    else:
                        continue
                if b[c]=="X" or b[c]=="O":
                    continue
                else:
                    b[c]=player
                    break
            print b[1],"|",b[2],"|",b[3]
            print "_________"
            print b[4],"|",b[5],"|",b[6]
            print "_________"
            print b[7],"|",b[8],"|",b[9]
            if b[1]==b[2]==b[3] or b[4]==b[5]==b[6] or b[7]==b[8]==b[9] or b[1]==b[4]==b[7] or b[2]==b[5]==b[8] or b[3]==b[6]==b[9] or b[1]==b[5]==b[9] or b[3]==b[5]==b[7]:
                print"You Won!!!!"
                break
            print "computer's turn"
            while True:
                f=random.randint(1,9)
                if b[f]=="X" or b[f]=="O":
                    continue
                else:
                    b[f]=computer
                    break
            print b[1],"|",b[2],"|",b[3]
            print "_________"
            print b[4],"|",b[5],"|",b[6]
            print "_________"
            print b[7],"|",b[8],"|",b[9]
            if b[1]==b[2]==b[3] or b[4]==b[5]==b[6] or b[7]==b[8]==b[9] or b[1]==b[4]==b[7] or b[2]==b[5]==b[8] or b[3]==b[6]==b[9] or b[1]==b[5]==b[9] or b[3]==b[5]==b[7]:
                print"Computer Won"
                break
        if 1 in b or 2 in b or 3 in b or 4 in b or 5 in b or 6 in b or 7 in b or 8 in b or 9 in b :
            continue
        else:
            print "It's tie"
            break
##################### END OF TIC TAC TOE #########################
            
            

        
        

########## IMPORTS #############
from timeit import default_timer
import random
######## END OF IMPORTS ########


score = [0,0]

masterlist = ['8675309', 'the coder', 'pikachoo is the best pokemon', 'Python is easiest language',"Quaid-e-Azam was a great personality"]
u=str(raw_input("For typing practice type T and press Enter.\nFor Games press G and press Enter.\n"))
              
################# GAMES #############################
if u =="g" or u=="G":
    m=str(raw_input("For Typing game press T and enter.\nFor Tic Tac Toe press X and enter"))
    if m=='t' or m=='T':
####################  LOOP FOR TYPING GAME   ##################
        while True:
            if score[0]==3 or score[1]==3:
                if score[0]==3:
                    print ("you won the game !")
                if score[1]==3:
                    print ("you are disgrace, you loose!!!!!")
                break
        
            else:
                textspeed = random.randint (7,18)
                a=random.randint(0,4)
                textToCopy= masterlist[a]
                score=game(textspeed,textToCopy,score)
                print("your score: {}".format(score[0]))
                print("The computer score: {}".format(score[1]))
    if m=='x' or m=='X':
###################### LOOP FOR TIC TAC TOE   #################
        while True:
            tic_tac_toe()

            t=str(raw_input("Play Again: press A & enter else enter"))
            if t=='a' or 'A':
                continue
            else:
                break
if u=="t" or u=="T":
####################### CODE FOR TYPING TUTORIAL   #############################
    i=str(raw_input("For different lessons type L1 or L2.......L3 and click enter"))
    c=i.split("L")
    l=len(c)
    if l==2:
        c[0]="l"
        c.append(".txt")
        k=c[0]+c[1]+c[2]
        x="p"+c[0]+c[1]+c[2]
    if l==1:
        c.append(".txt")
        k=c[0]+c[1]
        x="p"+c[0]+c[1]
    while True:
        print("You should type it in less than 60 seconds!!!")
        with open (k,'r') as output:
            w=output.readline().split()
        with open (x,'r') as output:
            for line in output:
                print line
            lets_start=str(raw_input("Press enter to get started "))
            starttime=default_timer()
            taking_input=str(raw_input(" "))
            stoptime = default_timer()
            q=taking_input.split()
           
        correct_words=0
        incorrect_words=0
        totalTime = stoptime - starttime
        for i in range (0,len(q)):
            e=w[i]
            r=q[i]
    
    
            if e==r:
                correct_words+=1
            else:
                incorrect_words+=1
        Total_words=correct_words+incorrect_words
        
        accuracy=float(float(float(correct_words)/float(Total_words))*100)
        
        speed= len(q)/totalTime
        print "Total time:{} s'".format(totalTime),"  Accuracy : {} %".format(accuracy),"  Speed: {} WPS".format(speed)
        t=str(raw_input("you have done it in {} seconds !!! \n for try again type t and press enter else only enter".format(totalTime)))
        if t=="t"or t=="T":
            continue
        else:
            break
############ END #############    
